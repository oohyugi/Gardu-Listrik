-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 18, 2017 at 09:51 AM
-- Server version: 5.5.53-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `gardu_listrik`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `nama`) VALUES
(1, 'admin', 'admin123', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `gardu`
--

CREATE TABLE IF NOT EXISTS `gardu` (
  `id_gardu` int(11) NOT NULL AUTO_INCREMENT,
  `alamat` varchar(300) NOT NULL,
  `daya` double NOT NULL,
  `feeder` varchar(300) NOT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `singk_gardu` varchar(100) NOT NULL,
  `jenis_gardu` varchar(100) NOT NULL,
  `nama_gardu` varchar(300) NOT NULL,
  `id_penyulang` int(12) NOT NULL,
  PRIMARY KEY (`id_gardu`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=39 ;

--
-- Dumping data for table `gardu`
--

INSERT INTO `gardu` (`id_gardu`, `alamat`, `daya`, `feeder`, `latitude`, `longitude`, `singk_gardu`, `jenis_gardu`, `nama_gardu`, `id_penyulang`) VALUES
(4, 'uwek', 23, '67', 24234, 3242343, '32', 'uwek', 'uwek', 1),
(6, 'test12', 23, '', 24234, 3242343, '32', 'ewr', 'rwe', 1),
(9, 'andro', 12, '120', 12, 12, 'qwer', 'qwer', 'qwer', 1),
(10, 'andro', 12, '120', 12, 12, 'qwer', 'qwer', 'qwer', 1),
(11, 'andro', 12, '120', 12, 12, 'qwer', 'qwer', 'qwer', 1),
(12, 'andro', 12, '120', 12, 12, 'qwer', 'qwer', 'qwer', 1),
(13, 'and', 12, '150', 12, 12, '120', 'asss', 'asss', 1),
(14, 'and', 12, '150', 12, 12, 'ssss', 'asss', 'asss', 1),
(15, 'testlagi', 120, '160', 6161, 62727, 'hs', 'ys', 'hsha', 2),
(16, 'testlagi', 120, '160', 6161, 62727, 'hs', 'ys', 'hsha', 2),
(17, 'testlagi', 120, '160', 6161, 62727, 'hs', 'ys', 'hsha', 2),
(18, 'tes', 12, '12', 12, 12, 'sa', 'a', 'as', 1),
(19, 'hshs', 12, '50', 15, 15, 'ga', 'ha', 'hs', 1),
(20, 'hshs', 12, '50', 15, 15, 'ga', 'ha', 'hs', 1),
(21, 'hshs', 12, '50', 15, 15, 'ga', 'ha', 'hs', 1),
(22, 'hshs', 12, '50', 15, 15, 'ga', 'ha', 'hs', 1),
(23, 'hshs', 12, '50', 15, 15, 'ga', 'ha', 'hs', 1),
(24, 'hshs', 12, '50', 15, 15, 'ga', 'ha', 'hs', 1),
(25, 'hshs', 12, '50', 15, 15, 'ga', 'ha', 'hs', 1),
(26, 'hshs', 12, '50', 15, 15, 'ga', 'ha', 'hs', 1),
(27, 'hshs', 12, '50', 15, 15, 'ga', 'ha', 'hs', 1),
(28, 'hshs', 12, '50', 15, 15, 'ga', 'ha', 'hs', 1),
(29, 'hshs', 12, '50', 15, 15, 'ga', 'ha', 'hs', 1),
(30, 'hshs', 12, '50', 15, 15, 'ga', 'ha', 'hs', 1),
(31, 'hshs', 12, '50', 15, 15, 'ga', 'ha', 'hs', 1),
(32, 'hshs', 12, '50', 15, 15, 'ga', 'ha', 'hs', 1),
(33, 'hshs', 12, '50', 15, 15, 'ga', 'ha', 'hs', 1),
(34, 'm', 64, '50', 2, 1, 'shs', 'hs', 'hss', 1),
(35, 'tes', 12, '12', 12, 12, 'sa', 'a', 'as', 1);

-- --------------------------------------------------------

--
-- Table structure for table `penyulang`
--

CREATE TABLE IF NOT EXISTS `penyulang` (
  `id_penyulang` int(12) NOT NULL AUTO_INCREMENT,
  `nama_gi` varchar(300) NOT NULL,
  `kode_gi` varchar(100) NOT NULL,
  `kode_penyulang` varchar(100) NOT NULL,
  `nama_penyulang` varchar(300) NOT NULL,
  PRIMARY KEY (`id_penyulang`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `penyulang`
--

INSERT INTO `penyulang` (`id_penyulang`, `nama_gi`, `kode_gi`, `kode_penyulang`, `nama_penyulang`) VALUES
(1, 'GH TRB', 'GE', '059', 'SUNGAI SAPIH'),
(2, 'asda', 'sdassd', 'asdas', 'test');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
