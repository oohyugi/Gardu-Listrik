<?php

include"koneksi.php";
$response=array();

$status= $_GET["status"];
switch ($status) {
	case '1':// insert
		$alamat=$_POST['alamat'];
		$daya=$_POST['daya'];
		$latitude=$_POST['latitude'];
		$longitude=$_POST['longitude'];
		$singk_gardu = $_POST['singk_gardu'];
		$jenis_gardu = $_POST['jenis_gardu'];
		$nama_gardu = $_POST['nama_gardu'];
		$id_penyulang = $_POST['id_penyulang'];
		$feeder = $_POST['feeder'];


		$query = "INSERT INTO gardu
		VALUES('','$alamat','$daya','$feeder','$latitude','$longitude','$singk_gardu','$jenis_gardu','$nama_gardu','$id_penyulang')";

		$result=mysqli_query($koneksi,$query);
		if ($result >0){
		 echo json_encode(
				
					"Data berhasil ditambahkan");


		}else{
		 echo json_encode(
				
					
					"Data gagal ditambahkan");

		}
		
	break;
	case '2'://update
		$alamat=$_POST['alamat'];
		$daya=$_POST['daya'];
		$latitude=$_POST['latitude'];
		$longitude=$_POST['longitude'];
		$singk_gardu = $_POST['singk_gardu'];
		$jenis_gardu = $_POST['jenis_gardu'];
		$nama_gardu = $_POST['nama_gardu'];
		$id_penyulang = $_POST['id_penyulang'];
		$id_gardu = $_POST['id_gardu'];
		$feeder = $_POST['feeder'];


		$query = "UPDATE  gardu
		set alamat='$alamat', daya='$daya',feeder='$feeder', latitude='$latitude', longitude='$longitude', singk_gardu='$singk_gardu',jenis_gardu='$jenis_gardu',nama_gardu='$nama_gardu',id_penyulang='$id_penyulang' WHERE id_gardu='$id_gardu'";

		$result=mysqli_query($koneksi,$query);
		if ($result >0){
		 echo json_encode(
				
				"Data berhasil diubah");

		}else{
		 echo json_encode(
			
					"Data gagal diupdate");

		}
	
	break;
	case '3'://delete
			$id_gardu = $_POST['id_gardu'];
		
		$query = "DELETE from gardu WHERE id_gardu='$id_gardu'";

		$result=mysqli_query($koneksi,$query);
		if ($result >0){
		 echo json_encode(
			
					"Data berhasil dihapus");

		}else{
		 echo json_encode(
				
					
					"Data gagal dihapus");
		}
		
		
	break;
	case '4'://login
			$username = $_GET['username'];
			$pass = $_GET['password'];
		
		$query = "SELECT * from admin WHERE username='$username' and password='$pass'";

		$result=mysqli_query($koneksi,$query);
		// echo $result;
		
		
		if ($result){
			foreach ($result as $data ) {
			$datas["data"]=array("nama"=>$data["nama"]

					);
		 	
		 }
		 echo json_encode(
				array(
					"status"=>200,
					"message"=>"sukses",
					"data"=>$datas["data"]));
		

		}else{
		 echo json_encode(
				array(
					"status"=>400,
					"message"=>"gagal",
					"data"=>"NULL"));

		}
		
		break;
	
	default:
		# code...
		break;
}




 ?>