<?php
	
include"koneksi.php";

$status= $_GET["status"];
/*1= penyulang
2= cari penyulang
3 = id trafo
4= cari id_trafo
5 = maps
6 = lokasi terdekat

*/

switch ($status) {
	case '1':
		$hasil="SELECT * FROM penyulang, gardu where penyulang.id_penyulang= gardu.id_penyulang  ";
		$query=mysqli_query($koneksi,$hasil);
		if ($query) {
				# code...
				
				foreach ($query as $value) {
				
					

				$datas["data"][]=array(

					"id_penyulang"=>$value["id_penyulang"],
					"nama_penyulang"=>$value["nama_penyulang"],
					"nama_gi"=>$value["nama_gi"],
					"kode_gi"=>$value["kode_gi"],
					"kode_penyulang"=> $value["kode_penyulang"],
					"id_gardu"=>$value["id_gardu"],
					"nama_gardu"=>$value["nama_gardu"],
					"alamat"=>$value["alamat"],
					"daya"=>$value["daya"],
					"feeder"=>$value["feeder"],
					"latitude"=>$value["latitude"],
					"longitude"=>$value["longitude"],
					"jenis_gardu"=>$value["jenis_gardu"],
					"singk_gardu"=>$value["singk_gardu"]

					);
			}
			echo json_encode(
				array(
					"status"=>200,
					"message"=>"sukses",
					"data"=>$datas["data"]));
			}else{
				echo json_encode(
				array(
					"status"=>400,
					"message"=>"not found"
					));
			}
		break;

	case '2':
	/*parameter status dan  nama penyulang*/
	$nama_penyulang =$_GET['nama_penyulang'];
	if (strlen($nama_penyulang)>=3) {
		$hasil="SELECT * FROM penyulang, gardu where penyulang.id_penyulang= gardu.id_penyulang  and nama_penyulang like '%".$nama_penyulang."%' ";
		$query=mysqli_query($koneksi,$hasil);
		if (mysqli_num_rows($query)>0) {
				# code...
				
				foreach ($query as $value) {
				
					

				$datas["data"][]=array(

					"id_penyulang"=>$value["id_penyulang"],
					"nama_penyulang"=>$value["nama_penyulang"],
					"nama_gi"=>$value["nama_gi"],
					"kode_gi"=>$value["kode_gi"],
					"kode_penyulang"=> $value["kode_penyulang"],
					"id_gardu"=>$value["id_gardu"],
					"nama_gardu"=>$value["nama_gardu"],
					"alamat"=>$value["alamat"],
					"daya"=>$value["daya"],
					"feeder"=>$value["feeder"],
					"latitude"=>$value["latitude"],
					"longitude"=>$value["longitude"],
					"jenis_gardu"=>$value["jenis_gardu"],
					"singk_gardu"=>$value["singk_gardu"]

					);
			}
			echo json_encode(
				array(
					"status"=>200,
					"message"=>"sukses",
					"data"=>$datas["data"]));
			}else{
				echo json_encode(
				array(
					"status"=>400,
					"message"=>"not found"
					));
			}
	}
		
	break;

	case '3':
		
			$hasil="SELECT * FROM penyulang, gardu where penyulang.id_penyulang= gardu.id_penyulang   ";
			$query=mysqli_query($koneksi,$hasil);
			if (mysqli_num_rows($query)>0) {
					# code...
					
					foreach ($query as $value) {
					
						

					$datas["data"][]=array(

						"id_penyulang"=>$value["id_penyulang"],
						"nama_penyulang"=>$value["nama_penyulang"],
						"nama_gi"=>$value["nama_gi"],
						"kode_gi"=>$value["kode_gi"],
						"kode_penyulang"=> $value["kode_penyulang"],
						"id_gardu"=>$value["id_gardu"],
						"nama_gardu"=>$value["nama_gardu"],
						"alamat"=>$value["alamat"],
						"daya"=>$value["daya"],
						"feeder"=>$value["feeder"],
						"latitude"=>$value["latitude"],
						"longitude"=>$value["longitude"],
						"jenis_gardu"=>$value["jenis_gardu"],
					"singk_gardu"=>$value["singk_gardu"]

						);
				}
				echo json_encode(
					array(
						"status"=>200,
						"message"=>"sukses",
						"data"=>$datas["data"]));
				}else{
					echo json_encode(
					array(
						"status"=>400,
						"message"=>"not found"
						));
				}
		
	break;

	case '4':
		/*parameter status dan  id_trafo*/
		$nama_gardu =$_GET['nama_gardu'];
		if (strlen($nama_gardu)>=3) {
			$hasil="SELECT * FROM penyulang, gardu where penyulang.id_penyulang= gardu.id_penyulang  and nama_gardu like '%".$nama_gardu."%' ";
			$query=mysqli_query($koneksi,$hasil);
			if (mysqli_num_rows($query)>0) {
					# code...
					
					foreach ($query as $value) {
					
						

					$datas["data"][]=array(

						"id_penyulang"=>$value["id_penyulang"],
						"nama_penyulang"=>$value["nama_penyulang"],
						"nama_gi"=>$value["nama_gi"],
						"kode_gi"=>$value["kode_gi"],
						"kode_penyulang"=> $value["kode_penyulang"],
						"id_gardu"=>$value["id_gardu"],
						"nama_gardu"=>$value["nama_gardu"],
						"alamat"=>$value["alamat"],
						"daya"=>$value["daya"],
						"feeder"=>$value["feeder"],
						"latitude"=>$value["latitude"],
						"longitude"=>$value["longitude"],
						"jenis_gardu"=>$value["jenis_gardu"],
					"singk_gardu"=>$value["singk_gardu"]

						);
				}
				echo json_encode(
					array(
						"status"=>200,
						"message"=>"sukses",
						"data"=>$datas["data"]));
				}else{
					echo json_encode(
					array(
						"status"=>400,
						"message"=>"not found"
						));
				}
		}
	break;

// MAPS
	case '5':
		$hasil="SELECT * FROM penyulang, gardu where penyulang.id_penyulang= gardu.id_penyulang  ";
			$query=mysqli_query($koneksi,$hasil);
			if ($query) {
					# code...
					
					foreach ($query as $value) {
					
						

					$datas["data"][]=array(

						"id_penyulang"=>$value["id_penyulang"],
						"nama_penyulang"=>$value["nama_penyulang"],
						"nama_gi"=>$value["nama_gi"],
						"kode_gi"=>$value["kode_gi"],
						"kode_penyulang"=> $value["kode_penyulang"],
						"id_gardu"=>$value["id_gardu"],
						"nama_gardu"=>$value["nama_gardu"],
						"alamat"=>$value["alamat"],
						"daya"=>$value["daya"],
						"feeder"=>$value["feeder"],
						"latitude"=>$value["latitude"],
						"longitude"=>$value["longitude"],
						"jenis_gardu"=>$value["jenis_gardu"],
					"singk_gardu"=>$value["singk_gardu"]

						);
				}
				echo json_encode(
					array(
						"status"=>200,
						"message"=>"sukses",
						"data"=>$datas["data"]));
				}else{
					echo json_encode(
					array(
						"status"=>400,
						"message"=>"not found"
						));
				}
		
	break;

	// LOKASI TERDEKAT
	case '6':
	$lat = $_GET['lat'];
	$lng = $_GET['lng'];
	 $jarak= $_GET['jarak'];
	
		$hasil="SELECT id_gardu,nama_gardu, feeder,latitude,longitude, alamat,daya,(6371 * ACOS(SIN(RADIANS(latitude)) * SIN(RADIANS($lat)) + COS(RADIANS(longitude - $lng)) * COS(RADIANS(latitude)) * COS(RADIANS($lat)))) AS jarak FROM  gardu  HAVING jarak < '$jarak'  ORDER BY jarak ASC ";
			$query=mysqli_query($koneksi,$hasil);
			
			if ($query==true) {
					# code...
					if (mysqli_num_rows($query)>0) {
						foreach ($query as $value) {
					
					$datas["data"][]=array(

					
						"id_gardu"=>$value["id_gardu"],
						"nama_gardu"=>$value["nama_gardu"],
						"alamat"=>$value["alamat"],
						"daya"=>$value["daya"],
						"feeder"=>$value["feeder"],
						"latitude"=>$value["latitude"],
						"longitude"=>$value["longitude"],
						"jarak"=>$value["jarak"],
				

						);
				}
				echo json_encode(
					array(
						"status"=>200,
						"message"=>"sukses",
						"data"=>$datas["data"]));

			
			}else{
				$datas["data"][]=array(

					
						"id_gardu"=>"id_gardu",
						"nama_gardu"=>"nama_gardu",
						"alamat"=>"alamat",
						

						);
				echo json_encode(
					array(
						"status"=>200,
						"message"=>"sukses",
						"data"=>$datas["data"]));
			}
					
				
				}else{
					echo json_encode(
					array(
						"status"=>400,
						"message"=>"not found"
						));
				}
				
				
	break;
	case '7':
		$hasil="SELECT * FROM penyulang ";
		$query=mysqli_query($koneksi,$hasil);
		if ($query) {
				# code...
				
				foreach ($query as $value) {
				
					

				$datas["data"][]=array(

					"id_penyulang"=>$value["id_penyulang"],
					"nama_penyulang"=>$value["nama_penyulang"]
					

					);
			}
			echo json_encode(
				array(
					"status"=>200,
					"message"=>"sukses",
					"data"=>$datas["data"]));
			}else{
				echo json_encode(
				array(
					"status"=>400,
					"message"=>"not found"
					));
			}
		break;
	
	default:
		# code...
		break;
}


?>
