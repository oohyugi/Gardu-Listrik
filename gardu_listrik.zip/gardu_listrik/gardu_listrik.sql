-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 21, 2016 at 07:16 PM
-- Server version: 5.5.53-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `gardu_listrik`
--

-- --------------------------------------------------------

--
-- Table structure for table `gardu`
--

CREATE TABLE IF NOT EXISTS `gardu` (
  `id_gardu` int(11) NOT NULL AUTO_INCREMENT,
  `alamat` varchar(300) NOT NULL,
  `daya` double NOT NULL,
  `feeder` varchar(300) NOT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `singk_gardu` varchar(100) NOT NULL,
  `jenis_gardu` varchar(100) NOT NULL,
  `nama_gardu` varchar(300) NOT NULL,
  `id_penyulang` int(12) NOT NULL,
  PRIMARY KEY (`id_gardu`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `gardu`
--

INSERT INTO `gardu` (`id_gardu`, `alamat`, `daya`, `feeder`, `latitude`, `longitude`, `singk_gardu`, `jenis_gardu`, `nama_gardu`, `id_penyulang`) VALUES
(1, 'DEKAT JEMBATAN AIA PACAH\r\n', 50, '120', -6.93118, 107.66359, 'Jap', 'T', 'GE059JAP0001T', 1),
(2, 'SAMPING KANTOR PLN', 50, '120', -6.933917, 107.66212, 'PLN\r\n', 'T', 'GE059PLN0002T', 1),
(3, 'dsfsdfs', 23, 'adasd', -6.866482, 107.624648, 'sdf', 'ss', 'sdfsd', 2);

-- --------------------------------------------------------

--
-- Table structure for table `penyulang`
--

CREATE TABLE IF NOT EXISTS `penyulang` (
  `id_penyulang` int(12) NOT NULL AUTO_INCREMENT,
  `nama_gi` varchar(300) NOT NULL,
  `kode_gi` varchar(100) NOT NULL,
  `kode_penyulang` varchar(100) NOT NULL,
  `nama_penyulang` varchar(300) NOT NULL,
  PRIMARY KEY (`id_penyulang`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `penyulang`
--

INSERT INTO `penyulang` (`id_penyulang`, `nama_gi`, `kode_gi`, `kode_penyulang`, `nama_penyulang`) VALUES
(1, 'GH TRB', 'GE', '059', 'SUNGAI SAPIH'),
(2, 'asda', 'sdassd', 'asdas', 'test');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
